package com.droidbyme.recyclerviewselection.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.droidbyme.recyclerviewselection.R;
import com.droidbyme.recyclerviewselection.activity.Classes;

public class Details extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        Bundle b = getIntent().getExtras();
        Classes c = (Classes) b.getSerializable("class");

        ImageView img = findViewById(R.id.imageView4);
        TextView className = findViewById(R.id.cName);
        TextView secN = findViewById(R.id.sNum);
        TextView isp = findViewById(R.id.open);
        TextView insN = findViewById(R.id.insN);

        img.setImageResource(c.getImage());
        className.setText(c.getC_Name());
        secN.setText(c.getSection_num()+"");
        isp.setText(c.isOpen()+"");
        insN.setText(c.getC_Instructor());

    }
}