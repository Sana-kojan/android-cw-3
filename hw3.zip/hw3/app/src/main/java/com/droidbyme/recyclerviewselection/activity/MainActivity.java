package com.droidbyme.recyclerviewselection.activity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.MenuItem;

import com.droidbyme.recyclerviewselection.R;


import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private classesAdapter adapter;
    private ArrayList<Classes> sa;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();}

    private void initView() {
        recyclerView = (RecyclerView) findViewById(R.id.rv);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        sa = new ArrayList<>();
        adapter = new classesAdapter(sa,this);
        recyclerView.setAdapter(adapter);
        createListData();
    }
    private void createListData() {
        Classes c1 = new Classes("Bio 110",  "11:00 am","Su-Tu-Th",false,81, R.drawable.bio);
        Classes c2 = new Classes("CSC 122", "15:00 Pm","Su-Tu-Th",true,81, R.drawable.cs);
        Classes c3 = new Classes("CSC 125",  "09:00 am","Su-Tu-Th",false,81,R.drawable.cs);
        Classes c4 = new Classes("MATH 131", "09:30 am","M-W",true,81,R.drawable.math);
        Classes c5 = new Classes("SPAN 101", "14:00 am","M-W",true,81, R.drawable.spanish);

        sa.add(c1);
        sa.add(c2);
        sa.add(c3);
        sa.add(c4);
        sa.add(c5);
        adapter.notifyDataSetChanged();





    }
}